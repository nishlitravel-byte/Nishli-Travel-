import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import WhatsAppButton from './components/WhatsAppButton';
import HeroSection from './sections/HeroSection';
import BeachSection from './sections/BeachSection';
import StaysSection from './sections/StaysSection';
import WildlifeSection from './sections/WildlifeSection';
import CultureSection from './sections/CultureSection';
import WellnessSection from './sections/WellnessSection';
import AdventureSection from './sections/AdventureSection';
import DiningSection from './sections/DiningSection';
import WhaleSection from './sections/WhaleSection';
import ItinerarySection from './sections/ItinerarySection';
import TestimonialsSection from './sections/TestimonialsSection';
import ContactSection from './sections/ContactSection';
import './App.css';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Global snap for pinned sections
    const setupGlobalSnap = () => {
      const pinned = ScrollTrigger.getAll()
        .filter(st => st.vars.pin)
        .sort((a, b) => a.start - b.start);
      
      const maxScroll = ScrollTrigger.maxScroll(window);
      if (!maxScroll || pinned.length === 0) return;

      const pinnedRanges = pinned.map(st => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            const inPinned = pinnedRanges.some(
              r => value >= r.start - 0.02 && value <= r.end + 0.02
            );
            if (!inPinned) return value;

            const target = pinnedRanges.reduce(
              (closest, r) =>
                Math.abs(r.center - value) < Math.abs(closest - value)
                  ? r.center
                  : closest,
              pinnedRanges[0]?.center ?? 0
            );
            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        },
      });
    };

    // Delay to allow all sections to register their ScrollTriggers
    const timer = setTimeout(setupGlobalSnap, 500);

    return () => {
      clearTimeout(timer);
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  return (
    <div ref={mainRef} className="relative">
      {/* Grain overlay */}
      <div className="grain-overlay" />
      
      {/* Navigation */}
      <Navbar />
      
      {/* Main content */}
      <main className="relative">
        {/* Section 1: Hero - z-10 */}
        <div className="relative z-10">
          <HeroSection />
        </div>
        
        {/* Section 2: Beach - z-20 */}
        <div className="relative z-20">
          <BeachSection />
        </div>
        
        {/* Section 3: Stays - z-30 */}
        <div className="relative z-30">
          <StaysSection />
        </div>
        
        {/* Section 4: Wildlife - z-40 */}
        <div className="relative z-40">
          <WildlifeSection />
        </div>
        
        {/* Section 5: Culture - z-50 */}
        <div className="relative z-50">
          <CultureSection />
        </div>
        
        {/* Section 6: Wellness - z-[60] */}
        <div className="relative z-[60]">
          <WellnessSection />
        </div>
        
        {/* Section 7: Adventure - z-[70] */}
        <div className="relative z-[70]">
          <AdventureSection />
        </div>
        
        {/* Section 8: Dining - z-[80] */}
        <div className="relative z-[80]">
          <DiningSection />
        </div>
        
        {/* Section 9: Whale - z-[90] */}
        <div className="relative z-[90]">
          <WhaleSection />
        </div>
        
        {/* Section 10: Itinerary - z-[100] (flowing) */}
        <div className="relative z-[100]">
          <ItinerarySection />
        </div>
        
        {/* Section 11: Testimonials - z-[110] (flowing) */}
        <div className="relative z-[110]">
          <TestimonialsSection />
        </div>
        
        {/* Section 12: Contact - z-[120] (flowing) */}
        <div className="relative z-[120]">
          <ContactSection />
        </div>
      </main>
      
      {/* Footer */}
      <Footer />
      
      {/* WhatsApp Floating Button */}
      <WhatsAppButton />
    </div>
  );
}

export default App;
