import { Phone, Mail, MapPin, Instagram, Facebook } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-jungle text-cream py-12 md:py-16">
      <div className="w-full px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-16">
          {/* Brand */}
          <div>
            <h3 className="font-sora font-bold text-2xl md:text-3xl mb-4">
              NISHLI
            </h3>
            <p className="text-cream/70 text-sm leading-relaxed max-w-xs">
              Curated Sri Lanka journeys, seamless stays, and unforgettable
              experiences—planned around you.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-sora font-semibold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a
                  href="#destinations"
                  className="text-cream/70 hover:text-gold transition-colors text-sm"
                >
                  Destinations
                </a>
              </li>
              <li>
                <a
                  href="#stays"
                  className="text-cream/70 hover:text-gold transition-colors text-sm"
                >
                  Stays
                </a>
              </li>
              <li>
                <a
                  href="#experiences"
                  className="text-cream/70 hover:text-gold transition-colors text-sm"
                >
                  Experiences
                </a>
              </li>
              <li>
                <a
                  href="#contact"
                  className="text-cream/70 hover:text-gold transition-colors text-sm"
                >
                  Contact
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-sora font-semibold text-lg mb-4">Contact Us</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-3">
                <Phone size={18} className="text-gold" />
                <a
                  href="tel:+94754229050"
                  className="text-cream/70 hover:text-gold transition-colors text-sm"
                >
                  +94 75 422 9050
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={18} className="text-gold" />
                <a
                  href="mailto:hello@nishli.travel"
                  className="text-cream/70 hover:text-gold transition-colors text-sm"
                >
                  hello@nishli.travel
                </a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin size={18} className="text-gold mt-0.5" />
                <span className="text-cream/70 text-sm">
                  Colombo, Sri Lanka
                </span>
              </li>
            </ul>

            {/* Social Links */}
            <div className="flex items-center gap-4 mt-6">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-cream/10 flex items-center justify-center hover:bg-gold transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={18} />
              </a>
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-cream/10 flex items-center justify-center hover:bg-gold transition-colors"
                aria-label="Facebook"
              >
                <Facebook size={18} />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-cream/10 mt-10 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-cream/50 text-xs">
            © {currentYear} NISHLI TRAVEL. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <a
              href="#"
              className="text-cream/50 hover:text-cream text-xs transition-colors"
            >
              Privacy Policy
            </a>
            <a
              href="#"
              className="text-cream/50 hover:text-cream text-xs transition-colors"
            >
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
