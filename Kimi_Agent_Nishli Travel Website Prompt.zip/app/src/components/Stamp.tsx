import { Compass } from 'lucide-react';

interface StampProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const Stamp = ({ className = '', size = 'md' }: StampProps) => {
  const sizeClasses = {
    sm: 'w-16 h-16',
    md: 'w-20 h-20 md:w-24 md:h-24',
    lg: 'w-24 h-24 md:w-28 md:h-28',
  };

  return (
    <div
      className={`${sizeClasses[size]} rounded-full bg-gold flex items-center justify-center shadow-panel ${className}`}
    >
      <svg viewBox="0 0 100 100" className="w-full h-full animate-spin-slow">
        {/* Circular text path */}
        <defs>
          <path
            id="circlePath"
            d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"
          />
        </defs>
        <text
          fill="#0B3A2C"
          fontSize="8"
          fontFamily="IBM Plex Mono"
          fontWeight="500"
          letterSpacing="2"
        >
          <textPath href="#circlePath">
            NISHLI TRAVEL • SRI LANKA • EXPLORE •
          </textPath>
        </text>
        {/* Center icon */}
        <foreignObject x="35" y="35" width="30" height="30">
          <div className="flex items-center justify-center w-full h-full">
            <Compass size={20} className="text-jungle" />
          </div>
        </foreignObject>
      </svg>
    </div>
  );
};

export default Stamp;
