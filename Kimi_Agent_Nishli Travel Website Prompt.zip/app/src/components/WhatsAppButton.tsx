import { MessageCircle } from 'lucide-react';

const WhatsAppButton = () => {
  const phoneNumber = '94754229050';
  const message = encodeURIComponent(
    'Hello NISHLI TRAVEL! I would like to inquire about planning a trip to Sri Lanka.'
  );

  return (
    <a
      href={`https://wa.me/${phoneNumber}?text=${message}`}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-[1000] w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform duration-300 animate-float"
      aria-label="Chat on WhatsApp"
    >
      <MessageCircle size={28} className="text-white fill-white" />
    </a>
  );
};

export default WhatsAppButton;
