import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Send, Phone, Mail, Clock, Shield, Check } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const ContactSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageCardRef = useRef<HTMLDivElement>(null);
  const contactPanelRef = useRef<HTMLDivElement>(null);
  const bottomCardsRef = useRef<HTMLDivElement>(null);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    travelMonth: '',
    message: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // Image card animation
      gsap.fromTo(
        imageCardRef.current,
        { y: '6vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Contact panel animation
      gsap.fromTo(
        contactPanelRef.current,
        { x: '8vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Bottom cards animation
      const bottomCards = bottomCardsRef.current?.querySelectorAll('.bottom-card');
      if (bottomCards) {
        gsap.fromTo(
          bottomCards,
          { y: '6vh', opacity: 0 },
          {
            y: 0,
            opacity: 1,
            stagger: 0.1,
            duration: 0.6,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: bottomCardsRef.current,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: '', email: '', travelMonth: '', message: '' });
    }, 3000);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="min-h-screen bg-jungle py-20 md:py-24"
    >
      <div className="w-full px-6 md:px-12">
        {/* Top Row - Image + Contact Panel */}
        <div className="flex flex-col lg:flex-row gap-6 mb-6">
          {/* Image Card */}
          <div
            ref={imageCardRef}
            className="lg:w-1/2 image-card overflow-hidden"
            style={{ height: '46vh', minHeight: '300px' }}
          >
            <img
              src="/closing_tea_hills.jpg"
              alt="Sri Lanka tea plantations"
              className="w-full h-full object-cover"
            />
          </div>

          {/* Contact Panel */}
          <div
            ref={contactPanelRef}
            className="lg:w-1/2 panel-rounded p-6 md:p-8 flex flex-col justify-between"
            style={{ height: '46vh', minHeight: '300px', backgroundColor: 'rgba(244,238,226,0.10)' }}
          >
            <div>
              <h2 className="font-sora font-bold text-cream text-2xl md:text-3xl lg:text-4xl leading-tight mb-4">
                Book your Sri Lanka trip
              </h2>
              <p className="text-cream/70 text-sm md:text-base leading-relaxed">
                Tell us when, who, and what you love. We'll reply within 24
                hours with a draft plan.
              </p>
            </div>

            <a
              href="https://wa.me/94754229050"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary flex items-center justify-center gap-2 self-start mt-6"
            >
              <Phone size={16} />
              Request a quote
            </a>
          </div>
        </div>

        {/* Bottom Row - Form + Details */}
        <div
          ref={bottomCardsRef}
          className="flex flex-col lg:flex-row gap-6"
        >
          {/* Form Card */}
          <div className="bottom-card lg:w-1/2 bg-cream/10 backdrop-blur-sm panel-rounded p-6 md:p-8">
            {isSubmitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center">
                <div className="w-16 h-16 rounded-full bg-gold/20 flex items-center justify-center mb-4">
                  <Check size={32} className="text-gold" />
                </div>
                <h3 className="font-sora font-bold text-cream text-xl mb-2">
                  Message sent!
                </h3>
                <p className="text-cream/70">
                  We'll get back to you within 24 hours.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-cream/70 text-sm mb-2">
                      Name
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-cream/10 border border-cream/20 rounded-xl text-cream placeholder-cream/40 focus:outline-none focus:border-gold transition-colors"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label className="block text-cream/70 text-sm mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 bg-cream/10 border border-cream/20 rounded-xl text-cream placeholder-cream/40 focus:outline-none focus:border-gold transition-colors"
                      placeholder="your@email.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-cream/70 text-sm mb-2">
                    Travel month
                  </label>
                  <select
                    name="travelMonth"
                    value={formData.travelMonth}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-cream/10 border border-cream/20 rounded-xl text-cream focus:outline-none focus:border-gold transition-colors appearance-none cursor-pointer"
                  >
                    <option value="" className="bg-jungle">
                      Select month
                    </option>
                    <option value="jan-mar" className="bg-jungle">
                      January - March
                    </option>
                    <option value="apr-jun" className="bg-jungle">
                      April - June
                    </option>
                    <option value="jul-sep" className="bg-jungle">
                      July - September
                    </option>
                    <option value="oct-dec" className="bg-jungle">
                      October - December
                    </option>
                  </select>
                </div>

                <div>
                  <label className="block text-cream/70 text-sm mb-2">
                    Message
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={3}
                    className="w-full px-4 py-3 bg-cream/10 border border-cream/20 rounded-xl text-cream placeholder-cream/40 focus:outline-none focus:border-gold transition-colors resize-none"
                    placeholder="Tell us about your dream trip..."
                  />
                </div>

                <button
                  type="submit"
                  className="btn-primary flex items-center justify-center gap-2 w-full sm:w-auto"
                >
                  <Send size={16} />
                  Send
                </button>
              </form>
            )}
          </div>

          {/* Details Card */}
          <div className="bottom-card lg:w-1/2 bg-cream/10 backdrop-blur-sm panel-rounded p-6 md:p-8">
            <h3 className="font-sora font-semibold text-cream text-lg mb-6">
              Contact details
            </h3>

            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-gold/20 flex items-center justify-center flex-shrink-0">
                  <Phone size={18} className="text-gold" />
                </div>
                <div>
                  <p className="text-cream/60 text-sm">WhatsApp</p>
                  <a
                    href="tel:+94754229050"
                    className="text-cream hover:text-gold transition-colors"
                  >
                    +94 75 422 9050
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-gold/20 flex items-center justify-center flex-shrink-0">
                  <Mail size={18} className="text-gold" />
                </div>
                <div>
                  <p className="text-cream/60 text-sm">Email</p>
                  <a
                    href="mailto:hello@nishli.travel"
                    className="text-cream hover:text-gold transition-colors"
                  >
                    hello@nishli.travel
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-gold/20 flex items-center justify-center flex-shrink-0">
                  <Clock size={18} className="text-gold" />
                </div>
                <div>
                  <p className="text-cream/60 text-sm">Response time</p>
                  <p className="text-cream">Within 24 hours</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-full bg-gold/20 flex items-center justify-center flex-shrink-0">
                  <Shield size={18} className="text-gold" />
                </div>
                <div>
                  <p className="text-cream/60 text-sm">Payments</p>
                  <p className="text-cream">Secure & flexible</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
