import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';
import Stamp from '../components/Stamp';

gsap.registerPlugin(ScrollTrigger);

const HeroSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageCardRef = useRef<HTMLDivElement>(null);
  const textPanelRef = useRef<HTMLDivElement>(null);
  const stampRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadlineRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);

  // Auto-play entrance animation on load
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      // Image card entrance
      tl.fromTo(
        imageCardRef.current,
        { opacity: 0, scale: 1.06, y: '6vh' },
        { opacity: 1, scale: 1, y: 0, duration: 1.1 },
        0
      );

      // Text panel entrance
      tl.fromTo(
        textPanelRef.current,
        { x: '-12vw', opacity: 0, rotate: -1 },
        { x: 0, opacity: 1, rotate: 0, duration: 1 },
        0.2
      );

      // Stamp entrance
      tl.fromTo(
        stampRef.current,
        { scale: 0, rotate: -120 },
        { scale: 1, rotate: 0, duration: 0.8, ease: 'back.out(1.8)' },
        0.4
      );

      // Headline words entrance
      if (headlineRef.current) {
        const words = headlineRef.current.querySelectorAll('.word');
        tl.fromTo(
          words,
          { y: 18, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.05, duration: 0.6 },
          0.5
        );
      }

      // Subheadline entrance
      tl.fromTo(
        subheadlineRef.current,
        { y: 12, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6 },
        0.7
      );

      // CTA entrance
      tl.fromTo(
        ctaRef.current,
        { y: 10, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5 },
        0.85
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Scroll-driven exit animation
  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements to visible when scrolling back to top
            gsap.set(imageCardRef.current, { x: 0, opacity: 1 });
            gsap.set(textPanelRef.current, { y: 0, opacity: 1 });
            gsap.set(stampRef.current, { scale: 1, rotate: 0, opacity: 1 });
          },
        },
      });

      // EXIT animations (70-100%)
      // Image card exit
      scrollTl.fromTo(
        imageCardRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      // Text panel exit
      scrollTl.fromTo(
        textPanelRef.current,
        { y: 0, opacity: 1 },
        { y: '10vh', opacity: 0, ease: 'power2.in' },
        0.7
      );

      // Stamp exit
      scrollTl.fromTo(
        stampRef.current,
        { scale: 1, rotate: 0, opacity: 1 },
        { scale: 0.6, rotate: 90, opacity: 0, ease: 'power2.in' },
        0.7
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const scrollToContact = () => {
    const contactSection = document.querySelector('#contact');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-sand flex items-center justify-center"
    >
      {/* Hero Image Card */}
      <div
        ref={imageCardRef}
        className="absolute image-card"
        style={{
          left: '6vw',
          top: '10vh',
          width: '88vw',
          height: '62vh',
        }}
      >
        <img
          src="/hero_aerial_coast.jpg"
          alt="Sri Lanka tropical beach aerial view"
          className="w-full h-full object-cover"
        />
        {/* Subtle gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-jungle/30 via-transparent to-transparent" />
      </div>

      {/* Text Panel */}
      <div
        ref={textPanelRef}
        className="absolute text-panel"
        style={{
          left: '10vw',
          top: '58vh',
          width: 'min(46vw, 560px)',
          minHeight: '28vh',
        }}
      >
        {/* Micro label */}
        <p className="font-mono text-xs uppercase tracking-[0.15em] text-gold mb-4">
          NISHLI TRAVEL
        </p>

        {/* Headline */}
        <h1
          ref={headlineRef}
          className="font-sora font-bold text-cream text-3xl md:text-4xl lg:text-5xl leading-tight mb-4"
        >
          <span className="word inline-block">Explore</span>{' '}
          <span className="word inline-block">Sri</span>{' '}
          <span className="word inline-block">Lanka</span>
        </h1>

        {/* Subheadline */}
        <p
          ref={subheadlineRef}
          className="text-cream/70 text-sm md:text-base leading-relaxed mb-6 max-w-md"
        >
          Curated tours, private drivers, and handpicked stays—planned around
          you.
        </p>

        {/* CTA Button */}
        <button
          ref={ctaRef}
          onClick={scrollToContact}
          className="btn-primary flex items-center gap-2 text-sm"
        >
          Start your trip
          <ArrowRight size={16} />
        </button>
      </div>

      {/* Stamp */}
      <div
        ref={stampRef}
        className="absolute"
        style={{
          right: '8vw',
          top: '14vh',
        }}
      >
        <Stamp />
      </div>
    </section>
  );
};

export default HeroSection;
