import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Calendar, MapPin, Heart, ArrowRight, Check } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const ItinerarySection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const leftColumnRef = useRef<HTMLDivElement>(null);
  const rightCardRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  const [selectedDuration, setSelectedDuration] = useState('7-10 days');
  const [selectedVibe, setSelectedVibe] = useState('balanced');
  const [selectedHighlights, setSelectedHighlights] = useState<string[]>([
    'beaches',
    'culture',
  ]);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // Left column animation
      gsap.fromTo(
        leftColumnRef.current,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Right preview card animation
      gsap.fromTo(
        rightCardRef.current,
        { x: '10vw', opacity: 0, scale: 0.98 },
        {
          x: 0,
          opacity: 1,
          scale: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Builder cards stagger animation
      const cards = cardsRef.current?.querySelectorAll('.builder-card');
      if (cards) {
        gsap.fromTo(
          cards,
          { y: 24, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            stagger: 0.08,
            duration: 0.6,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 85%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const durations = ['5-7 days', '7-10 days', '10-14 days', '14+ days'];
  const vibes = [
    { id: 'relaxed', label: 'Relaxed' },
    { id: 'balanced', label: 'Balanced' },
    { id: 'active', label: 'Active' },
  ];
  const highlights = [
    { id: 'beaches', label: 'Beaches', icon: MapPin },
    { id: 'culture', label: 'Culture', icon: Heart },
    { id: 'wildlife', label: 'Wildlife', icon: Calendar },
    { id: 'adventure', label: 'Adventure', icon: MapPin },
  ];

  const toggleHighlight = (id: string) => {
    setSelectedHighlights((prev) =>
      prev.includes(id) ? prev.filter((h) => h !== id) : [...prev, id]
    );
  };

  return (
    <section
      ref={sectionRef}
      className="min-h-screen bg-sand py-20 md:py-32"
    >
      <div className="w-full px-6 md:px-12">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-16">
          {/* Left Column - Builder UI */}
          <div ref={leftColumnRef} className="lg:w-1/2">
            <h2 className="font-sora font-bold text-jungle text-3xl md:text-4xl lg:text-5xl leading-tight mb-4">
              Build your itinerary
            </h2>
            <p className="text-jungle/70 text-base md:text-lg leading-relaxed mb-10 max-w-lg">
              Pick your pace, places, and vibe. We'll suggest a route, stays,
              and a driver—refined until it feels right.
            </p>

            {/* Builder Cards */}
            <div ref={cardsRef} className="space-y-4">
              {/* Duration Card */}
              <div className="builder-card bg-white/80 backdrop-blur-sm panel-rounded p-5 shadow-panel">
                <div className="flex items-center gap-3 mb-4">
                  <Calendar size={20} className="text-gold" />
                  <h3 className="font-sora font-semibold text-jungle">
                    Duration
                  </h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {durations.map((duration) => (
                    <button
                      key={duration}
                      onClick={() => setSelectedDuration(duration)}
                      className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                        selectedDuration === duration
                          ? 'bg-gold text-jungle'
                          : 'bg-sand text-jungle/70 hover:bg-sand/80'
                      }`}
                    >
                      {duration}
                    </button>
                  ))}
                </div>
              </div>

              {/* Vibe Card */}
              <div className="builder-card bg-white/80 backdrop-blur-sm panel-rounded p-5 shadow-panel">
                <div className="flex items-center gap-3 mb-4">
                  <Heart size={20} className="text-gold" />
                  <h3 className="font-sora font-semibold text-jungle">Vibe</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {vibes.map((vibe) => (
                    <button
                      key={vibe.id}
                      onClick={() => setSelectedVibe(vibe.id)}
                      className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                        selectedVibe === vibe.id
                          ? 'bg-gold text-jungle'
                          : 'bg-sand text-jungle/70 hover:bg-sand/80'
                      }`}
                    >
                      {vibe.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Highlights Card */}
              <div className="builder-card bg-white/80 backdrop-blur-sm panel-rounded p-5 shadow-panel">
                <div className="flex items-center gap-3 mb-4">
                  <MapPin size={20} className="text-gold" />
                  <h3 className="font-sora font-semibold text-jungle">
                    Must-sees
                  </h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {highlights.map((highlight) => {
                    const isSelected = selectedHighlights.includes(highlight.id);
                    return (
                      <button
                        key={highlight.id}
                        onClick={() => toggleHighlight(highlight.id)}
                        className={`px-4 py-2 rounded-full text-sm font-medium transition-all flex items-center gap-2 ${
                          isSelected
                            ? 'bg-gold text-jungle'
                            : 'bg-sand text-jungle/70 hover:bg-sand/80'
                        }`}
                      >
                        {isSelected && <Check size={14} />}
                        {highlight.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* CTA Buttons */}
              <div className="builder-card flex flex-col sm:flex-row gap-4 pt-4">
                <button className="btn-primary flex items-center justify-center gap-2">
                  Build itinerary
                  <ArrowRight size={16} />
                </button>
                <button className="text-jungle/70 hover:text-jungle font-medium text-sm underline underline-offset-4 transition-colors">
                  Or request a custom plan
                </button>
              </div>
            </div>
          </div>

          {/* Right Column - Preview Card */}
          <div ref={rightCardRef} className="lg:w-1/2">
            <div className="image-card bg-jungle p-6 md:p-8 h-full min-h-[400px] flex flex-col">
              <div className="flex-1">
                <p className="font-mono text-xs uppercase tracking-wider text-gold mb-4">
                  Sample Route Preview
                </p>
                <h3 className="font-sora font-bold text-cream text-xl md:text-2xl mb-6">
                  {selectedDuration} • {selectedVibe.charAt(0).toUpperCase() + selectedVibe.slice(1)} Journey
                </h3>

                {/* Route Timeline */}
                <div className="space-y-4">
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-full bg-gold/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-gold text-sm font-bold">1</span>
                    </div>
                    <div>
                      <p className="text-cream font-medium">Colombo</p>
                      <p className="text-cream/60 text-sm">Arrival & city exploration</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-full bg-gold/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-gold text-sm font-bold">2</span>
                    </div>
                    <div>
                      <p className="text-cream font-medium">Kandy & Hill Country</p>
                      <p className="text-cream/60 text-sm">Temples, tea estates & trains</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-full bg-gold/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-gold text-sm font-bold">3</span>
                    </div>
                    <div>
                      <p className="text-cream font-medium">Yala National Park</p>
                      <p className="text-cream/60 text-sm">Safari & wildlife spotting</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-full bg-gold/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-gold text-sm font-bold">4</span>
                    </div>
                    <div>
                      <p className="text-cream font-medium">South Coast Beaches</p>
                      <p className="text-cream/60 text-sm">Relaxation & whale watching</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Summary */}
              <div className="mt-6 pt-6 border-t border-cream/10">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-cream/60 text-sm">Selected highlights</p>
                    <p className="text-cream">
                      {selectedHighlights
                        .map((h) => h.charAt(0).toUpperCase() + h.slice(1))
                        .join(', ')}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-cream/60 text-sm">Est. starting from</p>
                    <p className="text-gold font-sora font-bold text-xl">
                      $1,200
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ItinerarySection;
