import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';
import Stamp from '../components/Stamp';

gsap.registerPlugin(ScrollTrigger);

const StaysSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageCardRef = useRef<HTMLDivElement>(null);
  const textPanelRef = useRef<HTMLDivElement>(null);
  const stampRef = useRef<HTMLDivElement>(null);
  const captionRef = useRef<HTMLParagraphElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0-30%)
      // Image card from right (different direction for rhythm)
      scrollTl.fromTo(
        imageCardRef.current,
        { x: '70vw', opacity: 0, scale: 0.97 },
        { x: 0, opacity: 1, scale: 1, ease: 'none' },
        0
      );

      // Text panel from left
      scrollTl.fromTo(
        textPanelRef.current,
        { x: '-40vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      // Stamp pop in
      scrollTl.fromTo(
        stampRef.current,
        { scale: 0, rotate: 140 },
        { scale: 1, rotate: 0, ease: 'back.out(1.4)' },
        0.05
      );

      // Caption fade in
      scrollTl.fromTo(
        captionRef.current,
        { y: 20, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.15
      );

      // EXIT (70-100%)
      scrollTl.fromTo(
        imageCardRef.current,
        { x: 0, opacity: 1 },
        { x: '18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        textPanelRef.current,
        { x: 0, opacity: 1 },
        { x: '-12vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        stampRef.current,
        { scale: 1, opacity: 1 },
        { scale: 0.5, opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        captionRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.75
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="stays"
      className="section-pinned bg-jungle flex items-center justify-center"
    >
      {/* Image Card */}
      <div
        ref={imageCardRef}
        className="absolute image-card"
        style={{
          left: '34vw',
          top: '12vh',
          width: '60vw',
          height: '70vh',
        }}
      >
        <img
          src="/pool_villa_jungle.jpg"
          alt="Luxury pool villa in Sri Lanka jungle"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Text Panel - subtle sand tint on green */}
      <div
        ref={textPanelRef}
        className="absolute flex flex-col justify-between panel-rounded p-6 md:p-8"
        style={{
          left: '6vw',
          top: '14vh',
          width: '28vw',
          minWidth: '300px',
          height: '72vh',
          backgroundColor: 'rgba(244,238,226,0.10)',
        }}
      >
        <div>
          <h2 className="font-sora font-bold text-cream text-2xl md:text-3xl lg:text-4xl leading-tight mb-4">
            Curated stays
          </h2>
          <p className="text-cream/70 text-sm md:text-base leading-relaxed">
            Boutique villas, eco-lodges, and guesthouses chosen for comfort,
            location, and hosts who care.
          </p>
        </div>

        <button className="btn-primary flex items-center gap-2 text-sm self-start mt-6">
          Browse stays
          <ArrowRight size={16} />
        </button>
      </div>

      {/* Stamp */}
      <div
        ref={stampRef}
        className="absolute"
        style={{
          left: '30vw',
          top: '10vh',
        }}
      >
        <Stamp size="sm" />
      </div>

      {/* Caption */}
      <p
        ref={captionRef}
        className="absolute font-mono text-xs uppercase tracking-wider text-cream/50"
        style={{
          left: '34vw',
          top: '86vh',
        }}
      >
        Handpicked properties — updated monthly
      </p>
    </section>
  );
};

export default StaysSection;
