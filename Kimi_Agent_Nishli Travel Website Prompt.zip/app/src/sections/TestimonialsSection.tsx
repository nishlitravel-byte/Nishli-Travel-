import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Quote } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const TestimonialsSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      // Headline animation
      gsap.fromTo(
        headlineRef.current,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards animation
      const cards = cardsRef.current?.querySelectorAll('.testimonial-card');
      if (cards) {
        gsap.fromTo(
          cards[0],
          { x: '12vw', opacity: 0, rotate: 1 },
          {
            x: 0,
            opacity: 1,
            rotate: 0,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 75%',
              toggleActions: 'play none none reverse',
            },
          }
        );

        gsap.fromTo(
          cards[1],
          { x: '14vw', opacity: 0, rotate: 2 },
          {
            x: 0,
            opacity: 0.9,
            rotate: 1,
            duration: 0.8,
            ease: 'power3.out',
            delay: 0.1,
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 75%',
              toggleActions: 'play none none reverse',
            },
          }
        );

        gsap.fromTo(
          cards[2],
          { x: '16vw', opacity: 0, rotate: 3 },
          {
            x: 0,
            opacity: 0.8,
            rotate: 2,
            duration: 0.8,
            ease: 'power3.out',
            delay: 0.2,
            scrollTrigger: {
              trigger: cardsRef.current,
              start: 'top 75%',
              toggleActions: 'play none none reverse',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const testimonials = [
    {
      quote:
        "Everything felt effortless—driver, hotels, timing. We just showed up.",
      name: 'Priya & Tom',
      location: 'UK',
      trip: '10-day cultural tour',
      avatar: 'PT',
    },
    {
      quote:
        'The whale trip alone was worth it. And the stays were so calm after busy days.',
      name: 'Lena',
      location: 'Germany',
      trip: '7-day beach & wildlife',
      avatar: 'L',
    },
    {
      quote: 'Second time with Nishli. Already planning the third.',
      name: 'Daniel',
      location: 'Netherlands',
      trip: '14-day island explorer',
      avatar: 'D',
    },
  ];

  return (
    <section
      ref={sectionRef}
      className="min-h-screen bg-sand py-20 md:py-32"
    >
      <div className="w-full px-6 md:px-12">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-16">
          {/* Left Column - Headline */}
          <div ref={headlineRef} className="lg:w-2/5">
            <h2 className="font-sora font-bold text-jungle text-3xl md:text-4xl lg:text-5xl leading-tight mb-4">
              What travelers say
            </h2>
            <p className="text-jungle/70 text-base md:text-lg leading-relaxed max-w-md">
              Real trips, real feedback—most come back for a second route.
            </p>
          </div>

          {/* Right Column - Stacked Cards */}
          <div ref={cardsRef} className="lg:w-3/5 relative">
            <div className="relative space-y-4">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className="testimonial-card bg-white/90 backdrop-blur-sm panel-rounded p-6 md:p-8 shadow-panel"
                  style={{
                    marginLeft: `${index * 16}px`,
                    zIndex: 3 - index,
                  }}
                >
                  <Quote
                    size={24}
                    className="text-gold mb-4"
                    fill="currentColor"
                  />
                  <p className="text-jungle text-lg md:text-xl leading-relaxed mb-6">
                    "{testimonial.quote}"
                  </p>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-jungle flex items-center justify-center">
                      <span className="text-cream font-sora font-semibold">
                        {testimonial.avatar}
                      </span>
                    </div>
                    <div>
                      <p className="font-sora font-semibold text-jungle">
                        {testimonial.name}
                      </p>
                      <p className="text-jungle/60 text-sm">
                        {testimonial.location} • {testimonial.trip}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
