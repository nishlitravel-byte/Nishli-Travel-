import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight } from 'lucide-react';
import Stamp from '../components/Stamp';

gsap.registerPlugin(ScrollTrigger);

const WellnessSection = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageCardRef = useRef<HTMLDivElement>(null);
  const textPanelRef = useRef<HTMLDivElement>(null);
  const stampRef = useRef<HTMLDivElement>(null);
  const captionRef = useRef<HTMLParagraphElement>(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // ENTRANCE (0-30%)
      scrollTl.fromTo(
        imageCardRef.current,
        { x: '-60vw', opacity: 0, scale: 0.96 },
        { x: 0, opacity: 1, scale: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        textPanelRef.current,
        { x: '40vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0
      );

      scrollTl.fromTo(
        stampRef.current,
        { scale: 0, rotate: -140 },
        { scale: 1, rotate: 0, ease: 'back.out(1.4)' },
        0.05
      );

      scrollTl.fromTo(
        captionRef.current,
        { y: 20, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.15
      );

      // EXIT (70-100%)
      scrollTl.fromTo(
        imageCardRef.current,
        { x: 0, opacity: 1 },
        { x: '-18vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        textPanelRef.current,
        { x: 0, opacity: 1 },
        { x: '12vw', opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        stampRef.current,
        { scale: 1, opacity: 1 },
        { scale: 0.5, opacity: 0, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        captionRef.current,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.75
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-sand flex items-center justify-center"
    >
      {/* Image Card */}
      <div
        ref={imageCardRef}
        className="absolute image-card"
        style={{
          left: '6vw',
          top: '12vh',
          width: '62vw',
          height: '70vh',
        }}
      >
        <img
          src="/yoga_deck_view.jpg"
          alt="Yoga deck with valley view in Sri Lanka"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Text Panel */}
      <div
        ref={textPanelRef}
        className="absolute text-panel flex flex-col justify-between"
        style={{
          left: '70vw',
          top: '14vh',
          width: '24vw',
          minWidth: '280px',
          height: '72vh',
        }}
      >
        <div>
          <h2 className="font-sora font-bold text-cream text-2xl md:text-3xl lg:text-4xl leading-tight mb-4">
            Wellness & relaxation
          </h2>
          <p className="text-cream/70 text-sm md:text-base leading-relaxed">
            Ayurveda, yoga, and quiet mornings—built into your itinerary without
            losing the adventure.
          </p>
        </div>

        <button className="btn-primary flex items-center gap-2 text-sm self-start mt-6">
          Add wellness days
          <ArrowRight size={16} />
        </button>
      </div>

      {/* Stamp */}
      <div
        ref={stampRef}
        className="absolute"
        style={{
          left: '58vw',
          top: '10vh',
        }}
      >
        <Stamp size="sm" />
      </div>

      {/* Caption */}
      <p
        ref={captionRef}
        className="absolute font-mono text-xs uppercase tracking-wider text-jungle/60"
        style={{
          left: '6vw',
          top: '86vh',
        }}
      >
        Retreats & spa partners
      </p>
    </section>
  );
};

export default WellnessSection;
